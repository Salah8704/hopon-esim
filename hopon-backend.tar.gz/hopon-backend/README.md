# hopOn Backend — Guide d'intégration

## Architecture

```
hopOn Backend (Node.js + Express)
├── API Publique         → site frontend (catalogue, commandes)
├── Webhooks             → WooCommerce (paiement validé)
├── Worker Bull/Redis    → traitement asynchrone eSIM
├── Cron                 → sync catalogue (toutes les 4h)
└── Admin API            → dashboard admin (gestion des prix, stock, logs)
        |
        ├── Transatel OCS Catalog API    → sync catalogue
        ├── Transatel OCS Subscription   → souscription produit
        ├── Transatel SIM Management     → activation code, QR code
        ├── Transatel Connectivity Mgmt  → statut subscriber
        └── PostgreSQL + Redis           → persistance + queues
```

## Workflow complet après achat

```
Client → WooCommerce (paiement) → Webhook → Backend
                                              ↓
                                    Réserver SIM depuis stock
                                              ↓
                                    Souscrire produit (OCS API)
                                              ↓
                                    Attendre confirmation (poll/webhook)
                                              ↓
                                    Récupérer activation_code + QR code
                                              ↓
                                    Email premium au client
                                              ↓
                                    Espace client mis à jour
```

## Setup rapide

```bash
# 1. Cloner et configurer
cp .env.example .env
# Remplir OCS_USERNAME, OCS_PASSWORD, WC_*, SMTP_*, etc.

# 2. Démarrer avec Docker
docker-compose up -d

# 3. OU démarrer en local
npm install
npm run migrate   # Crée les tables PostgreSQL
npm run dev       # Serveur dev avec nodemon

# 4. Première sync catalogue
npm run sync:catalog
```

## Variables d'environnement obligatoires

| Variable           | Description                              |
|--------------------|------------------------------------------|
| OCS_USERNAME       | Username Transatel SPC                   |
| OCS_PASSWORD       | Password Transatel SPC                   |
| COS_REF            | WW_M2MA_COS_SPC                          |
| DATABASE_URL       | PostgreSQL connection string             |
| REDIS_URL          | Redis URL pour Bull queues               |
| WC_BASE_URL        | URL du site WooCommerce                  |
| WC_CONSUMER_KEY    | Clé consommateur WC REST API             |
| WC_CONSUMER_SECRET | Secret consommateur WC REST API          |
| WC_WEBHOOK_SECRET  | Secret HMAC pour la vérification webhook |
| JWT_SECRET         | Secret JWT (min 32 chars, aléatoire)     |
| BREVO_API_KEY      | Clé API Brevo pour l'envoi d'emails      |

## Règle de prix (non négociable)

Un produit n'est jamais publié automatiquement.

Le flux est :
1. Sync API → `supplier_price` stocké, `price_status = 'pending_review'`
2. Admin fixe `public_price` via le dashboard
3. Admin valide → `price_status = 'validated'`, `is_published = true`
4. WooCommerce reçoit le prix via `PUT /wc/v3/products/{id}`

**Jamais :** prix inventé, extrapolé, déduit d'un autre forfait.

## API Endpoints

### Public (frontend)
- `GET /api/v1/catalog/countries` — liste des pays
- `GET /api/v1/catalog/countries/:iso2` — pays + forfaits
- `GET /api/v1/catalog/products?country=MA&duration=7` — forfaits filtrés
- `GET /health` — statut serveur

### Webhooks
- `POST /webhooks/woocommerce` — événements WC (HMAC requis)

### Admin (JWT admin requis)
- `GET  /api/v1/admin/dashboard` — overview
- `GET  /api/v1/admin/products?price_status=pending_review` — produits à valider
- `POST /api/v1/admin/products/:id/validate` — valider un prix
- `POST /api/v1/admin/sync/catalog` — déclencher une sync
- `GET  /api/v1/admin/sync/logs` — logs de sync
- `GET  /api/v1/admin/stock` — état du stock eSIM
- `POST /api/v1/admin/stock/import` — importer des ICCIDs
- `GET  /api/v1/admin/orders` — commandes

## Contact & support
contact@hopon.fr
